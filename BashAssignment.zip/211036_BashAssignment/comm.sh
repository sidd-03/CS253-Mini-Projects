#!/bin/bash
if [ $# -ne 2 ]; 
then 
 echo "Give two arguments"
exit 1
fi


if [[ ! -f "$1" || ! -f "$2" ]]; 
then 
 echo "Input file does not exist"
exit 1
fi

while read -r line; do
awk -v var="$line" '$0 == var { if($0 !~ /^[[:space:]]*$/) print $0 }' "$2"
done < "$1"

#echo "FINISH"