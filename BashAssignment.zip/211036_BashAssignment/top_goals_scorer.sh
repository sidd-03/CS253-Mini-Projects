#!/bin/bash
if [ $# -ne 2 ]; 
then 
 echo "Give two arguments"
exit 1
fi

if [ ! -f"$1" ]; 
then 
 echo "Input file does not exist"
exit 1
fi

echo "full_name,age,birthday,birthday_GMT,league,season,position,CurrentClub,minutes_played_overall,minutes_played_home,minutes_played_away,nationality,appearances_overall,appearances_home,appearances_away,goals_overall,goals_home,goals_away,assists_overall,assists_home,assists_away,penalty_goals,penalty_misses,clean_sheets_overall,clean_sheets_home,clean_sheets_away,conceded_overall,conceded_home,conceded_away,yellow_cards_overall,red_cards_overall,goals_involved_per_90_overall,assists_per_90_overall,goals_per_90_overall,goals_per_90_home,goals_per_90_away,min_per_goal_overall,conceded_per_90_overall,min_per_conceded_overall,min_per_match,min_per_card_overall,min_per_assist_overall,cards_per_90_overall,rank_in_league_top_attackers,rank_in_league_top_midfielders,rank_in_league_top_defenders,rank_in_club_top_scorer"> "$2"

awk -F "," 'NR>1 {print $16}' "$1" | sort -rn | uniq > sortgoals.txt

while read -r goal; do
awk -F ',' -v var="$goal" '$16 == var' "$1" >> "$2"
done < <(head -n 10 sortgoals.txt)


 
