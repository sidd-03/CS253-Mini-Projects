#!/bin/bash
if [ $# -ne 2 ]; 
then 
 echo "Give two arguments"
exit 1
fi

if [ ! -f"$1" ]; 
then 
 echo "Input file does not exist"
exit 1
fi

echo "full_name,nationality,position,goals_overall"> "$2"
 

awk -F "," 'NR>1 {print $16}' "$1" | sort -rn | uniq > goals.txt

while read -r goal; do
awk -F ',' -v var="$goal" '$16 == var && $7 == "Goalkeeper" {print $1","$12","$7","$16}' "$1" >> "$2"
awk -F ',' -v var="$goal" '$16 == var && $7 == "Defender" {print $1","$12","$7","$16}' "$1" >> "$2"
awk -F ',' -v var="$goal" '$16 == var && $7 == "Midfielder" {print $1","$12","$7","$16}' "$1" >> "$2"
awk -F ',' -v var="$goal" '$16 == var && $7 == "Forward" {print $1","$12","$7","$16}' "$1" >> "$2"

done < goals.txt

#echo "FINISH"
